# MovieCatalog — Android Медіа-каталог та Відеоплеєр

## Інструкція зі встановлення

### 1. Відкрийте проєкт в Android Studio
- Розпакуйте архів
- Відкрийте Android Studio → File → Open → оберіть теку проєкту

### 2. Налаштуйте local.properties
- Скопіюйте `local.properties.example` як `local.properties`
- Вкажіть шлях до Android SDK
- Вкажіть TMDB Bearer Token та API Key

### 3. Синхронізуйте Gradle
- File → Sync Project with Gradle Files
- Дочекайтесь завантаження залежностей

### 4. Зберіть проєкт
- Build → Make Project (Ctrl+F9)
- Або через термінал: `./gradlew assembleDebug`

### 5. Запустіть на пристрої
- Підключіть Android телефон або емулятор
- Run → Run 'app' (Shift+F10)

### 6. Для Android TV
- Встановіть APK через ADB:
  ```
  adb connect <TV_IP>:5555
  adb install app/build/outputs/apk/debug/app-debug.apk
  ```

### 7. Підписання Release APK
```bash
# Створіть ключ
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key

# Зберіть release
./gradlew assembleRelease

# Підпишіть APK
apksigner sign --ks release-key.jks app/build/outputs/apk/release/app-release-unsigned.apk
```

## Технічний стек
- Kotlin 1.9+ / Jetpack Compose / Material3
- Media3 ExoPlayer 1.4+ (HLS, DASH, MP4)
- Hilt (DI) / Room / DataStore
- TMDB API / OkHttp / Jsoup
- minSdk 24 / targetSdk 34

## Функціонал
- Каталог фільмів/серіалів з TMDB
- Пошук з debounce та історією
- 21 джерело відео (українські кінотеатри + балансери)
- Універсальний медіа-екстрактор
- Відеоплеєр з вибором мови та якості
- PiP, Foreground Service
- Android TV підтримка (D-pad навігація)
- Темна/світла тема з динамічними кольорами
