package com.example.moviecatalog.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

@Singleton
class AppPreferences @Inject constructor(
    private val context: Context
) {
    companion object {
        val PREFERRED_LANGUAGE = stringPreferencesKey("preferred_language")
        val PREFERRED_QUALITY = stringPreferencesKey("preferred_quality")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    val preferredLanguage: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[PREFERRED_LANGUAGE] ?: "uk"
    }

    val preferredQuality: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[PREFERRED_QUALITY] ?: "1080p"
    }

    val themeMode: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[THEME_MODE] ?: "system"
    }

    suspend fun setPreferredLanguage(language: String) {
        context.dataStore.edit { it[PREFERRED_LANGUAGE] = language }
    }

    suspend fun setPreferredQuality(quality: String) {
        context.dataStore.edit { it[PREFERRED_QUALITY] = quality }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[THEME_MODE] = mode }
    }
}
