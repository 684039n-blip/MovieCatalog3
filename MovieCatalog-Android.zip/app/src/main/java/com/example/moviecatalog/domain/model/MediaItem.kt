package com.example.moviecatalog.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class MediaItem(
    val id: Int,
    val title: String,
    val originalTitle: String,
    val overview: String,
    val posterPath: String?,
    val backdropPath: String?,
    val releaseDate: String?,
    val voteAverage: Double,
    val mediaType: MediaType,
    val genreIds: List<Int> = emptyList(),
    val originCountry: List<String> = emptyList()
)

@Serializable
enum class MediaType {
    MOVIE, TV, ANIME, CARTOON
}

@Serializable
data class MediaDetails(
    val item: MediaItem,
    val genres: List<Genre>,
    val cast: List<CastMember>,
    val similar: List<MediaItem>,
    val runtime: Int?,
    val numberOfSeasons: Int?,
    val status: String?,
    val tagline: String?
)

@Serializable
data class Genre(
    val id: Int,
    val name: String
)

@Serializable
data class CastMember(
    val id: Int,
    val name: String,
    val character: String,
    val profilePath: String?
)
