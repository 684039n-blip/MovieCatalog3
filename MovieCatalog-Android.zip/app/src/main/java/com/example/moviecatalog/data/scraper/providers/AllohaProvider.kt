package com.example.moviecatalog.data.scraper.providers

import com.example.moviecatalog.data.scraper.SourceProvider
import com.example.moviecatalog.data.scraper.UniversalMediaExtractor
import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.StreamOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject

/**
 * Alloha — балансир відео.
 */
class AllohaProvider @Inject constructor(
    private val httpClient: OkHttpClient,
    private val extractor: UniversalMediaExtractor
) : SourceProvider {
    override val name = "Alloha"
    override val baseUrl = "https://alloha.tv"

    override suspend fun search(query: String): List<SourceSearchResult> = withContext(Dispatchers.IO) {
        try {
            val searchUrl = "$baseUrl/search?query=$query"
            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "Mozilla/5.0 Chrome/120.0.0.0")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }
            val doc = Jsoup.parse(html)
            doc.select("div.search-result-item, div.card").mapNotNull { el ->
                val title = el.select("a").attr("title").ifEmpty { el.select("a").text() }
                val href = el.select("a").attr("href")
                val poster = el.select("img").attr("src")
                if (title.isNotEmpty() && href.isNotEmpty()) {
                    SourceSearchResult(title, href, null, poster, name)
                } else null
            }
        } catch (e: Exception) {
            Timber.e(e, "Alloha: помилка пошуку")
            emptyList()
        }
    }

    override suspend fun resolveStreams(url: String): List<StreamOption> {
        return extractor.extract(url, name)
    }
}
