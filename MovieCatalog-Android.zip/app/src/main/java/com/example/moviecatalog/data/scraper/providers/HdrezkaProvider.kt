package com.example.moviecatalog.data.scraper.providers

import com.example.moviecatalog.data.scraper.SourceProvider
import com.example.moviecatalog.data.scraper.UniversalMediaExtractor
import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.StreamOption
import com.example.moviecatalog.domain.model.StreamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject

/**
 * Парсер для hdrezka-ua.com
 * HDRezka використовує власний плеєр з CDN. Шукаємо .m3u8 у init-скрипті.
 */
class HdrezkaProvider @Inject constructor(
    private val httpClient: OkHttpClient,
    private val extractor: UniversalMediaExtractor
) : SourceProvider {
    override val name = "HDRezka"
    override val baseUrl = "https://hdrezka-ua.com"

    override suspend fun search(query: String): List<SourceSearchResult> = withContext(Dispatchers.IO) {
        try {
            val searchUrl = "$baseUrl/engine/ajax/suggest.php?q=$query"
            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "Mozilla/5.0 Chrome/120.0.0.0")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }
            // Парсимо JSON-відповідь suggest
            val doc = Jsoup.parse(html)
            doc.select("li").mapNotNull { element ->
                val title = element.select(".title").text()
                val href = element.select("a").attr("href")
                val poster = element.select("img").attr("src")
                if (title.isNotEmpty() && href.isNotEmpty()) {
                    SourceSearchResult(title, href, null, poster, name)
                } else null
            }
        } catch (e: Exception) {
            Timber.e(e, "HDRezka: помилка пошуку")
            emptyList()
        }
    }

    override suspend fun resolveStreams(url: String): List<StreamOption> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120.0.0.0 Mobile")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }

            // HDRezka зберігає посилання на стріми в data-атрибутах або inline JS
            val streams = mutableListOf<StreamOption>()
            val m3u8Regex = Regex("""https?://[^\s"']+\.m3u8[^\s"']*""")
            m3u8Regex.findAll(html).forEach { match ->
                streams.add(StreamOption(
                    url = match.value,
                    quality = extractQuality(match.value),
                    language = "uk",
                    type = StreamType.HLS,
                    sourceName = name
                ))
            }

            if (streams.isEmpty()) {
                streams.addAll(extractor.extract(url, name))
            }
            streams
        } catch (e: Exception) {
            Timber.e(e, "HDRezka: помилка resolveStreams")
            emptyList()
        }
    }

    private fun extractQuality(url: String): String? {
        return Regex("""(\d{3,4})p""").find(url)?.value
    }
}
