package com.example.moviecatalog.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviecatalog.data.tmdb.TmdbRepository
import com.example.moviecatalog.domain.model.MediaItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = true,
    val trending: List<MediaItem> = emptyList(),
    val topMovies: List<MediaItem> = emptyList(),
    val topSeries: List<MediaItem> = emptyList(),
    val nowPlaying: List<MediaItem> = emptyList(),
    val cartoons: List<MediaItem> = emptyList(),
    val anime: List<MediaItem> = emptyList()
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: TmdbRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            val trending = repository.getTrending()
            val topMovies = repository.getTopRatedMovies()
            val topSeries = repository.getTopRatedTv()
            val nowPlaying = repository.getNowPlaying()
            val cartoons = repository.getCartoons()
            val anime = repository.getAnime()

            _uiState.value = HomeUiState(
                isLoading = false,
                trending = trending,
                topMovies = topMovies,
                topSeries = topSeries,
                nowPlaying = nowPlaying,
                cartoons = cartoons,
                anime = anime
            )
        }
    }

    fun refresh() {
        loadData()
    }
}
