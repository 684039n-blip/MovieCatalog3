package com.example.moviecatalog.ui.screens.player

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.util.Rational
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun PlayerScreen(
    streamUrl: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var exoPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showQualityDialog by remember { mutableStateOf(false) }
    var tracks by remember { mutableStateOf<Tracks?>(null) }

    // Ініціалізація ExoPlayer
    LaunchedEffect(streamUrl) {
        val player = ExoPlayer.Builder(context).build().apply {
            val mediaItem = MediaItem.fromUri(streamUrl)
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true

            // Встановлюємо бажану мову аудіо — українська
            trackSelector.let { selector ->
                if (selector is androidx.media3.exoplayer.trackselection.DefaultTrackSelector) {
                    selector.setParameters(
                        selector.buildUponParameters()
                            .setPreferredAudioLanguage("ukr")
                            .setPreferredAudioLanguage("uk")
                    )
                }
            }

            addListener(object : androidx.media3.common.Player.Listener {
                override fun onTracksChanged(newTracks: Tracks) {
                    tracks = newTracks
                }
            })
        }
        exoPlayer = player
    }

    // Cleanup
    DisposableEffect(Unit) {
        onDispose {
            exoPlayer?.release()
        }
    }

    // PiP support
    val activity = context as? android.app.Activity
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
            try {
                activity.enterPictureInPictureMode(
                    PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9))
                        .build()
                )
            } catch (_: Exception) {}
        }
    }

    BackHandler {
        exoPlayer?.pause()
        onBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Player View
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = exoPlayer
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    useController = true
                    setControllerVisibilityListener(
                        object : androidx.media3.ui.PlayerView.ControllerVisibilityListener {
                            @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                            override fun onVisibility(visibility: Int) {
                                showControls = visibility == android.view.View.VISIBLE
                            }
                        }
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top controls overlay
        if (showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                // Language button
                IconButton(onClick = { showLanguageDialog = true }) {
                    Icon(Icons.Default.Subtitles, "Мова", tint = Color.White)
                }
                // Quality button
                IconButton(onClick = { showQualityDialog = true }) {
                    Icon(Icons.Default.HighQuality, "Якість", tint = Color.White)
                }
                // Close button
                IconButton(onClick = {
                    exoPlayer?.pause()
                    onBack()
                }) {
                    Icon(Icons.Default.Close, "Закрити", tint = Color.White)
                }
            }
        }
    }

    // Language selection dialog
    if (showLanguageDialog && tracks != null) {
        LanguageSelectionDialog(
            tracks = tracks!!,
            onDismiss = { showLanguageDialog = false },
            onLanguageSelected = { group, index ->
                exoPlayer?.let { player ->
                    player.setTrackSelection(
                        TrackSelectionOverride(group, listOf(index))
                    )
                }
                showLanguageDialog = false
            }
        )
    }

    // Quality selection dialog
    if (showQualityDialog && tracks != null) {
        QualitySelectionDialog(
            tracks = tracks!!,
            onDismiss = { showQualityDialog = false },
            onQualitySelected = { group, index ->
                exoPlayer?.let { player ->
                    player.setTrackSelection(
                        TrackSelectionOverride(group, listOf(index))
                    )
                }
                showQualityDialog = false
            }
        )
    }
}

@Composable
private fun LanguageSelectionDialog(
    tracks: Tracks,
    onDismiss: () -> Unit,
    onLanguageSelected: (Tracks.Group, Int) -> Unit
) {
    val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Оберіть мову") },
        text = {
            Column {
                audioGroups.forEach { group ->
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val language = format.language ?: "Невідомо"
                        val label = group.getMediaTrackFormat(i).label ?: language
                        TextButton(
                            onClick = { onLanguageSelected(group, i) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("$label ($language)")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Скасувати") }
        }
    )
}

@Composable
private fun QualitySelectionDialog(
    tracks: Tracks,
    onDismiss: () -> Unit,
    onQualitySelected: (Tracks.Group, Int) -> Unit
) {
    val videoGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Оберіть якість") },
        text = {
            Column {
                videoGroups.forEach { group ->
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val height = format.height
                        val bitrate = format.bitrate / 1000
                        val label = if (height > 0) "${height}p" else "${bitrate}kbps"
                        TextButton(
                            onClick = { onQualitySelected(group, i) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(label)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Скасувати") }
        }
    )
}
