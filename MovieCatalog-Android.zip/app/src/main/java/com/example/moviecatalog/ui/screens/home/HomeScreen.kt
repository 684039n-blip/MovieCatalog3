package com.example.moviecatalog.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.moviecatalog.R
import com.example.moviecatalog.domain.model.MediaItem
import com.example.moviecatalog.domain.model.MediaType
import com.example.moviecatalog.ui.components.MediaCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onMediaClick: (String, Int) -> Unit,
    onSearchClick: () -> Unit,
    onCatalogClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("КіноКаталог", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onSearchClick) {
                        Icon(Icons.Default.Search, contentDescription = "Пошук")
                    }
                    IconButton(onClick = onCatalogClick) {
                        Icon(Icons.Default.List, contentDescription = "Каталог")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // Тренди
            if (uiState.trending.isNotEmpty()) {
                item {
                    SectionHeader(title = "🔥 Тренди")
                    MediaRow(items = uiState.trending, onMediaClick = onMediaClick)
                }
            }
            // Топ фільми
            if (uiState.topMovies.isNotEmpty()) {
                item {
                    SectionHeader(title = "⭐ Топ фільми")
                    MediaRow(items = uiState.topMovies, onMediaClick = onMediaClick)
                }
            }
            // Топ серіали
            if (uiState.topSeries.isNotEmpty()) {
                item {
                    SectionHeader(title = "📺 Топ серіали")
                    MediaRow(items = uiState.topSeries, onMediaClick = onMediaClick)
                }
            }
            // Новинки
            if (uiState.nowPlaying.isNotEmpty()) {
                item {
                    SectionHeader(title = "🎬 Новинки")
                    MediaRow(items = uiState.nowPlaying, onMediaClick = onMediaClick)
                }
            }
            // Мультфільми
            if (uiState.cartoons.isNotEmpty()) {
                item {
                    SectionHeader(title = "🎨 Мультфільми")
                    MediaRow(items = uiState.cartoons, onMediaClick = onMediaClick)
                }
            }
            // Аніме
            if (uiState.anime.isNotEmpty()) {
                item {
                    SectionHeader(title = "🌸 Аніме")
                    MediaRow(items = uiState.anime, onMediaClick = onMediaClick)
                }
            }

            if (uiState.isLoading) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
private fun MediaRow(
    items: List<MediaItem>,
    onMediaClick: (String, Int) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items) { item ->
            val type = when (item.mediaType) {
                MediaType.TV, MediaType.ANIME -> "tv"
                else -> "movie"
            }
            MediaCard(
                title = item.title,
                posterPath = item.posterPath,
                voteAverage = item.voteAverage,
                onClick = { onMediaClick(type, item.id) }
            )
        }
    }
}
