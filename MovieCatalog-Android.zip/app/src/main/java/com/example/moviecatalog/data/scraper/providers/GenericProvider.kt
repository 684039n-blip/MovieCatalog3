package com.example.moviecatalog.data.scraper.providers

import com.example.moviecatalog.data.scraper.SourceProvider
import com.example.moviecatalog.data.scraper.UniversalMediaExtractor
import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.StreamOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject

/**
 * Універсальний провайдер для сайтів зі стандартною структурою.
 * Використовується як fallback для більшості балансирів.
 */
class GenericProvider @Inject constructor(
    private val httpClient: OkHttpClient,
    private val extractor: UniversalMediaExtractor,
    private val providerName: String,
    private val providerBaseUrl: String
) : SourceProvider {
    override val name = providerName
    override val baseUrl = providerBaseUrl

    override suspend fun search(query: String): List<SourceSearchResult> = withContext(Dispatchers.IO) {
        try {
            // Стандартний пошук через ?s=query або /search?q=query
            val searchUrl = "$baseUrl/?s=$query"
            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120.0.0.0 Mobile")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }
            val doc = Jsoup.parse(html)

            // Шукаємо стандартні елементи результатів
            doc.select("article, .post, .movie-item, .search-result, .item").mapNotNull { el ->
                val link = el.select("a[href]").firstOrNull() ?: return@mapNotNull null
                val title = link.attr("title").ifEmpty { link.text() }
                val href = link.attr("href")
                val poster = el.select("img").attr("src").ifEmpty { el.select("img").attr("data-src") }
                if (title.isNotEmpty() && href.isNotEmpty() && href.startsWith("http")) {
                    SourceSearchResult(title, href, null, poster, name)
                } else null
            }.distinctBy { it.url }
        } catch (e: Exception) {
            Timber.e(e, "$name: помилка пошуку")
            emptyList()
        }
    }

    override suspend fun resolveStreams(url: String): List<StreamOption> {
        return extractor.extract(url, name)
    }
}
