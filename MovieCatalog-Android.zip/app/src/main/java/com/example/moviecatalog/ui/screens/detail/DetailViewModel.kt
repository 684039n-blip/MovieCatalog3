package com.example.moviecatalog.ui.screens.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviecatalog.data.local.dao.BookmarkDao
import com.example.moviecatalog.data.local.entity.BookmarkEntity
import com.example.moviecatalog.data.tmdb.TmdbRepository
import com.example.moviecatalog.domain.model.MediaDetails
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailUiState(
    val isLoading: Boolean = true,
    val details: MediaDetails? = null,
    val isBookmarked: Boolean = false
)

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: TmdbRepository,
    private val bookmarkDao: BookmarkDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(DetailUiState())
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    private var currentMediaId: Int = 0

    fun loadDetails(mediaType: String, mediaId: Int) {
        currentMediaId = mediaId
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            val details = when (mediaType) {
                "tv" -> repository.getTvDetails(mediaId)
                else -> repository.getMovieDetails(mediaId)
            }

            val isBookmarked = bookmarkDao.isBookmarked(mediaId)

            _uiState.value = DetailUiState(
                isLoading = false,
                details = details,
                isBookmarked = isBookmarked
            )
        }
    }

    fun toggleBookmark() {
        viewModelScope.launch {
            val details = _uiState.value.details ?: return@launch
            val item = details.item

            if (_uiState.value.isBookmarked) {
                bookmarkDao.deleteById(item.id)
                _uiState.value = _uiState.value.copy(isBookmarked = false)
            } else {
                bookmarkDao.insert(
                    BookmarkEntity(
                        id = item.id,
                        title = item.title,
                        posterPath = item.posterPath,
                        mediaType = item.mediaType.name,
                        voteAverage = item.voteAverage,
                        releaseDate = item.releaseDate
                    )
                )
                _uiState.value = _uiState.value.copy(isBookmarked = true)
            }
        }
    }
}
