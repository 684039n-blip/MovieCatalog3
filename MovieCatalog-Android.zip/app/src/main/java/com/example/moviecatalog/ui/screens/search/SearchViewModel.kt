package com.example.moviecatalog.ui.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviecatalog.data.local.dao.SearchHistoryDao
import com.example.moviecatalog.data.local.entity.SearchHistoryEntity
import com.example.moviecatalog.data.tmdb.TmdbRepository
import com.example.moviecatalog.domain.model.MediaItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val isLoading: Boolean = false,
    val results: List<MediaItem> = emptyList(),
    val recentSearches: List<String> = emptyList()
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: TmdbRepository,
    private val searchHistoryDao: SearchHistoryDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            searchHistoryDao.getRecentSearches().collect { history ->
                _uiState.value = _uiState.value.copy(
                    recentSearches = history.map { it.query }
                )
            }
        }
    }

    fun onQueryChanged(query: String) {
        searchJob?.cancel()
        if (query.length < 2) {
            _uiState.value = _uiState.value.copy(results = emptyList(), isLoading = false)
            return
        }
        searchJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            delay(300) // Debounce 300ms
            val results = repository.search(query)
            _uiState.value = _uiState.value.copy(isLoading = false, results = results)

            // Зберігаємо в історію
            if (results.isNotEmpty()) {
                searchHistoryDao.insert(SearchHistoryEntity(query))
            }
        }
    }
}
