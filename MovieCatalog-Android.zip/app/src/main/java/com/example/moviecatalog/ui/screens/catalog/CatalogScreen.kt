package com.example.moviecatalog.ui.screens.catalog

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.moviecatalog.domain.model.MediaType
import com.example.moviecatalog.ui.components.MediaCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(
    onMediaClick: (String, Int) -> Unit,
    onBack: () -> Unit,
    viewModel: CatalogViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Каталог") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Назад")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            // Фільтри-чіпи
            ScrollableTabRow(
                selectedTabIndex = uiState.selectedTabIndex,
                modifier = Modifier.fillMaxWidth()
            ) {
                uiState.tabs.forEachIndexed { index, tab ->
                    Tab(
                        selected = index == uiState.selectedTabIndex,
                        onClick = { viewModel.selectTab(index) },
                        text = { Text(tab) }
                    )
                }
            }

            // Жанри
            if (uiState.genres.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    uiState.genres.take(5).forEach { genre ->
                        FilterChip(
                            selected = uiState.selectedGenreId == genre.id,
                            onClick = { viewModel.selectGenre(genre.id) },
                            label = { Text(genre.name) }
                        )
                    }
                }
            }

            // Сітка контенту
            LazyVerticalGrid(
                columns = GridCells.Adaptive(120.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.items) { item ->
                    val type = when (item.mediaType) {
                        MediaType.TV, MediaType.ANIME -> "tv"
                        else -> "movie"
                    }
                    MediaCard(
                        title = item.title,
                        posterPath = item.posterPath,
                        voteAverage = item.voteAverage,
                        onClick = { onMediaClick(type, item.id) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
