# ProGuard rules for MovieCatalog

# Keep Retrofit interfaces
-keep,allowobfuscation,allowshrinking interface retrofit2.Call
-keep,allowobfuscation,allowshrinking class retrofit2.Response

# Keep data classes
-keep class com.example.moviecatalog.data.tmdb.dto.** { *; }
-keep class com.example.moviecatalog.domain.model.** { *; }

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.example.moviecatalog.**$$serializer { *; }
-keepclassmembers class com.example.moviecatalog.** { *** Companion; }
-keepclasseswithmembers class com.example.moviecatalog.** { kotlinx.serialization.KSerializer serializer(...); }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Jsoup
-keeppackagenames org.jsoup.nodes

# Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Hilt
-keep class dagger.hilt.** { *; }
